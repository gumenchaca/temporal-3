let tabData = {};
let donutSlices = [];
let lineChartData = {};
let currentLineFilter = "all";
let activeLineCohort = "all";

// Keep these declarations before initializeConfig so calls are always in scope.
let renderLineLegend = function renderLineLegend(filter = currentLineFilter) {
    const legendEl = document.getElementById("line-chart-legend");
    if (!legendEl || !lineChartData || !lineChartData.cohorts) {
        return;
    }

    const visibleCohorts = filter === "millennials"
        ? lineChartData.cohorts.filter((c) => ["p18_34", "p35_49", "p50_64"].includes(c.id))
        : lineChartData.cohorts;

    legendEl.innerHTML = visibleCohorts.map((item) => `
        <button type="button" class="line-legend-item" data-cohort="${item.id}" aria-label="Highlight ${item.label}">
            <span class="line-legend-swatch" style="--legend-color:${item.color};"></span>
            <span class="line-legend-label">${item.label}</span>
        </button>
    `).join("");

    legendEl.querySelectorAll(".line-legend-item").forEach((legendItem) => {
        legendItem.addEventListener("click", () => {
            const cohortId = legendItem.getAttribute("data-cohort") || "all";
            const next = activeLineCohort === cohortId ? "all" : cohortId;
            updateLineChartHighlight(next);
        });
    });
};

let renderLineChart = function renderLineChart(filter = currentLineFilter) {
    const svgWrap = document.getElementById("line-chart-svg-wrap");
    if (!svgWrap || !lineChartData || !lineChartData.data || !lineChartData.cohorts) {
        return;
    }

    const filterConfig = {
        "all": {
            points: lineChartData.data,
            cohorts: lineChartData.cohorts
        },
        "last-12": {
            points: lineChartData.data.slice(-4),
            cohorts: lineChartData.cohorts
        },
        "last-6": {
            points: lineChartData.data.slice(-2),
            cohorts: lineChartData.cohorts
        },
        "millennials": {
            points: lineChartData.data,
            cohorts: lineChartData.cohorts.filter((c) => ["p18_34", "p35_49", "p50_64"].includes(c.id))
        }
    };

    const selected = filterConfig[filter] || filterConfig.all;
    const points = selected.points;
    const cohorts = selected.cohorts;

    if (!points.length || !cohorts.length) {
        svgWrap.innerHTML = "";
        return;
    }

    const width = 550;
    const height = 300;
    const paddingLeft = 40;
    const paddingRight = 42;
    const paddingTop = 24;
    const paddingBottom = 60;
    const chartWidth = width - paddingLeft - paddingRight;
    const chartHeight = height - paddingTop - paddingBottom;

    const maxRaw = Math.max(
        ...points.flatMap((row) => cohorts.map((cohort) => Number(row[cohort.id] || 0))),
        1
    );
    const headRoom = maxRaw * 1.12;
    const yTicks = 6;
    const rawStep = headRoom / yTicks;
    let step;
    if (rawStep > 250000) {
        step = Math.ceil(rawStep / 100000) * 100000;
    } else if (rawStep > 100000) {
        step = Math.ceil(rawStep / 50000) * 50000;
    } else if (rawStep > 50000) {
        step = Math.ceil(rawStep / 25000) * 25000;
    } else {
        step = Math.ceil(rawStep / 1000) * 1000;
    }
    const yMax = step * yTicks;

    const xFor = (index) => {
        if (points.length === 1) {
            return paddingLeft + (chartWidth / 2);
        }
        return paddingLeft + (index * chartWidth) / (points.length - 1);
    };
    const yFor = (value) => paddingTop + chartHeight * (1 - (value / yMax));

    let gridHtml = "";
    for (let i = 0; i <= yTicks; i += 1) {
        const value = Math.round((yMax / yTicks) * i);
        const y = yFor(value);
        const label = value === 0 ? "0" : `${Math.round(value / 1000)}k`;
        gridHtml += `
            <g class="line-grid-row">
                <line x1="${paddingLeft}" y1="${y}" x2="${width - paddingRight}" y2="${y}" stroke="rgba(255,255,255,0.14)" stroke-width="1" />
                <!-- Left Axis Label -->
                <text x="${paddingLeft - 10}" y="${y + 4}" fill="rgba(255,255,255,0.55)" font-size="10" text-anchor="end">${label}</text>
                <!-- Right Axis Label (for scroll support visibility) -->
                <text x="${width - paddingRight + 8}" y="${y + 4}" fill="rgba(255,255,255,0.55)" font-size="10" text-anchor="start">${label}</text>
            </g>
        `;
    }

    // Dynamic X label color from parent container's class to satisfy requirements
    const parentPanel = svgWrap?.closest("[class*='accent-']") || svgWrap?.closest(".custom-design-card");
    let xTickLabelColor = "rgba(255, 255, 255, 0.72)";
    if (parentPanel) {
        xTickLabelColor = "#c084fc"; // purple-400 equivalent for Samsung
    }

    let axisHtml = "";
    points.forEach((row, index) => {
        const x = xFor(index);
        axisHtml += `
            <g class="line-x-tick">
                <line x1="${x}" y1="${height - paddingBottom}" x2="${x}" y2="${height - paddingBottom + 6}" stroke="rgba(255,255,255,0.25)" stroke-width="1" />
                <text x="0" y="0" transform="translate(${x}, ${height - paddingBottom + 20}) rotate(-35)" fill="${xTickLabelColor}" font-size="10" text-anchor="end" font-weight="500">${row.quarter}</text>
            </g>
        `;
    });

    let pathsHtml = "";
    let dotsHtml = "";

    cohorts.forEach((cohort) => {
        const pathPoints = [];

        points.forEach((row, index) => {
            const value = Number(row[cohort.id] || 0);
            const x = xFor(index);
            const y = yFor(value);
            pathPoints.push(`${x},${y}`);

            dotsHtml += `
                <circle
                    class="js-chart-trigger chart-dot"
                    cx="${x}"
                    cy="${y}"
                    r="4.4"
                    fill="#ffffff"
                    stroke="${cohort.color}"
                    stroke-width="2.6"
                    data-type="line"
                    data-cohort="${cohort.id}"
                    data-title="${cohort.label} • ${row.quarter}"
                    data-color="${cohort.color}"
                    data-percent="${value.toLocaleString("en-US")}"
                />
            `;
        });

        pathsHtml += `
            <path
                class="line-path"
                d="M ${pathPoints.join(" L ")}"
                fill="none"
                stroke="${cohort.color}"
                stroke-width="2.8"
                stroke-linecap="round"
                stroke-linejoin="round"
                data-cohort="${cohort.id}"
                opacity="0.9"
            />
        `;
    });

    svgWrap.innerHTML = `
        <svg viewBox="0 0 ${width} ${height}" class="w-full h-auto select-none overflow-visible">
            ${gridHtml}
            ${axisHtml}
            <g class="line-series-paths">${pathsHtml}</g>
            <g class="line-series-dots">${dotsHtml}</g>
        </svg>
    `;

    updateLineChartHighlight(activeLineCohort);

    svgWrap.querySelectorAll(".chart-dot").forEach((trigger) => {
        trigger.addEventListener("mouseenter", () => {
            if (typeof showOverlay === "function" && !isMobile) {
                showOverlay(trigger);
            }
        });
        trigger.addEventListener("mouseleave", () => {
            if (typeof hideOverlay === "function" && !isMobile) {
                hideOverlay();
            }
        });
        trigger.addEventListener("click", () => {
            if (typeof showOverlay === "function" && isMobile) {
                showOverlay(trigger);
            }
        });
    });
};

let updateLineChartHighlight = function updateLineChartHighlight(cohortId = "all") {
    activeLineCohort = cohortId || "all";

    const paths = document.querySelectorAll(".line-path");
    const dots = document.querySelectorAll(".chart-dot");
    const legendDots = document.querySelectorAll("#line-chart-legend .line-legend-item");

    if (activeLineCohort === "all") {
        paths.forEach((path) => {
            path.style.opacity = "0.9";
            path.style.strokeWidth = "2.8";
        });
        dots.forEach((dot) => {
            dot.style.opacity = "1";
            dot.setAttribute("r", "4.4");
            dot.style.strokeWidth = "2.6";
        });
        legendDots.forEach((dot) => {
            dot.style.opacity = "0.95";
            dot.classList.remove("is-active");
        });
        return;
    }

    paths.forEach((path) => {
        const match = path.getAttribute("data-cohort") === activeLineCohort;
        path.style.opacity = match ? "1" : "0.12";
        path.style.strokeWidth = match ? "4" : "1.6";
    });
    dots.forEach((dot) => {
        const match = dot.getAttribute("data-cohort") === activeLineCohort;
        dot.style.opacity = match ? "1" : "0.08";
        dot.setAttribute("r", match ? "5.8" : "3");
        dot.style.strokeWidth = match ? "3.2" : "1.6";
    });
    legendDots.forEach((dot) => {
        const match = dot.getAttribute("data-cohort") === activeLineCohort;
        dot.style.opacity = match ? "1" : "0.35";
        dot.classList.toggle("is-active", match);
    });
};

let setupTimeframeDropdown = function setupTimeframeDropdown() {
    const dropdownContainer = document.getElementById("timeframe-dropdown-container");
    const dropdownBtn = document.getElementById("timeframe-dropdown-btn");
    const dropdownMenu = document.getElementById("timeframe-dropdown-menu");
    const selectedLabel = document.getElementById("selected-timeframe-label");
    const dropdownChevron = document.getElementById("dropdown-chevron");

    if (!dropdownContainer || !dropdownBtn || !dropdownMenu || !selectedLabel) {
        return;
    }

    const closeMenu = () => {
        dropdownMenu.classList.add("hidden");
        if (dropdownChevron) {
            dropdownChevron.classList.remove("rotate-180");
        }
    };

    dropdownBtn.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        dropdownMenu.classList.toggle("hidden");
        if (dropdownChevron) {
            dropdownChevron.classList.toggle("rotate-180");
        }
    });

    document.addEventListener("click", (event) => {
        if (!dropdownContainer.contains(event.target)) {
            closeMenu();
        }
    });

    dropdownMenu.querySelectorAll(".dropdown-item").forEach((item) => {
        item.addEventListener("click", () => {
            const filter = item.getAttribute("data-filter") || "all";
            selectedLabel.textContent = item.textContent.trim();
            currentLineFilter = filter;
            activeLineCohort = "all";
            renderLineLegend(currentLineFilter);
            renderLineChart(currentLineFilter);
            animateLineChartDraw();
            closeMenu();
        });
    });
};

let setupCohortDropdown = function setupCohortDropdown() {};

let animateLineChartDraw = function animateLineChartDraw() {
    const paths = document.querySelectorAll(".line-path");
    const dots = document.querySelectorAll(".chart-dot");

    paths.forEach((path) => {
        const length = path.getTotalLength();
        path.style.strokeDasharray = `${length}`;
        path.style.strokeDashoffset = `${length}`;
        path.getBoundingClientRect();
        path.style.transition = "stroke-dashoffset 1.2s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s ease";
        path.style.strokeDashoffset = "0";
    });

    dots.forEach((dot, index) => {
        const cx = dot.getAttribute("cx") || "0";
        const cy = dot.getAttribute("cy") || "0";
        dot.style.opacity = "0";
        dot.style.transformOrigin = `${cx}px ${cy}px`;
        dot.style.transform = "scale(0)";
        setTimeout(() => {
            dot.style.transition = "opacity 0.25s ease-out, transform 0.25s ease-out";
            dot.style.opacity = "1";
            dot.style.transform = "scale(1)";
        }, 350 + (index % 10) * 20);
    });
};

// Initialize variables immediately with global configuration from config.js
(function initializeConfig() {
    tabData = configData.streamingShows;
    donutSlices = configData.donutSlices;
    lineChartData = configData.lineChart;
    
    // Update Behavior Insights targets, units (prefix/suffix/decimals) and copy dynamically
    const updateBehaviorStat = (elId, configObj) => {
        const el = document.querySelector(elId);
        if (el && configObj) {
            el.setAttribute("data-target", configObj.target !== undefined ? configObj.target : "0");
            el.setAttribute("data-prefix", configObj.prefix || "");
            el.setAttribute("data-suffix", configObj.suffix || "");
            el.setAttribute("data-decimals", configObj.decimals !== undefined ? configObj.decimals : "0");
            
            let initialVal = "0";
            if (configObj.decimals && configObj.decimals > 0) {
                initialVal = (0).toFixed(configObj.decimals);
            }
            el.textContent = (configObj.prefix || "") + initialVal + (configObj.suffix || "");
            
            // Update the corresponding label copy
            const labelEl = document.querySelector(`${elId}-label`);
            if (labelEl) {
                labelEl.innerHTML = configObj.copy || "";
            }
        }
    };

    updateBehaviorStat('#stat-main', configData.behaviorInsights.mainStat);
    updateBehaviorStat('#stat-worldcup', configData.behaviorInsights.worldCupBookings);
    updateBehaviorStat('#stat-adr', configData.behaviorInsights.adr);
    updateBehaviorStat('#stat-conversion', configData.behaviorInsights.conversionRate);
    updateBehaviorStat('#stat-impressions', configData.behaviorInsights.campaignImpressions);
    
    // Build Sports Insights (formerly Fan Insights) Cards
    const sportsGridEl = document.getElementById("sports-insights-grid");
    if (sportsGridEl && configData.fanInsights) {
        sportsGridEl.innerHTML = configData.fanInsights.map(card => `
            <div class="fan-card-container w-full h-[15rem] relative select-none cursor-pointer">
                <div class="fan-card-inner absolute inset-0 w-full h-full">
                    <!-- FRONT FACE -->
                    <div class="fan-card-front text-left !justify-center !gap-[0.75rem]">
                        <div class="flex justify-between items-start w-full">
                            <span class="fan-value">${card.title}</span>
                            <button class="transition duration-300 ease-in-out hover:scale-110 cursor-pointer js-flip-btn text-white mt-1" type="button" aria-label="Flip Card">
                                <img src="./assets/icons/ArrowsClockwise.svg" alt="Flip Card" class="fan-card-icon w-5 h-5 opacity-80 hover:opacity-100" />
                            </button>
                        </div>
                        <p class="fan-copy">${card.front}</p>
                    </div>
                    <!-- BACK FACE -->
                    <div class="fan-card-back text-white text-left !justify-between !gap-0">
                        <div class="flex justify-between items-start w-full">
                            <span class="font-display text-[18px] uppercase leading-none tracking-wider">${card.title}</span>
                            <button class="transition duration-300 ease-in-out hover:scale-110 cursor-pointer js-flip-btn mt-1" type="button" aria-label="Flip Card">
                                <img src="./assets/icons/ArrowsClockwise.svg" alt="Flip Card" class="fan-card-icon w-5 h-5 opacity-80 hover:opacity-100 brightness-0 invert" />
                            </button>
                        </div>
                        <p class="fan-copy mt-auto">${card.back}</p>
                    </div>
                </div>
            </div>
        `).join('');

        // Attach event listener for card flip on click
        sportsGridEl.querySelectorAll(".fan-card-container").forEach(cardContainer => {
            cardContainer.addEventListener("click", () => {
                cardContainer.classList.toggle("is-flipped");
            });
        });
    }
    
    // Build Sources List
    const sourcesListEl = document.getElementById("sources-list");
    if (sourcesListEl && configData.sources) {
        sourcesListEl.innerHTML = configData.sources.map(source => `
            <div>
                <h3 class="source-title">${source.title}</h3>
                <p class="text-xs sm:text-sm text-white/80">${source.description}</p>
            </div>
        `).join('');
    }
    
    // Build Line Chart Legend
    renderLineLegend(currentLineFilter);

    // Render active SVG line chart with full data at startup
    renderLineChart();

    // Setup active dropdown selectors
    setupTimeframeDropdown();

    // Only animate the line chart draw when scrolled to!
    const lineChartObserver = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateLineChartDraw();
                obs.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15 });

    const lineSvgWrap = document.getElementById("line-chart-svg-wrap");
    if (lineSvgWrap) {
        lineChartObserver.observe(lineSvgWrap);
    }

    // Custom Scrollbar HUD Sync & Action Controllers
    document.querySelectorAll(".custom-scroll-hud").forEach(hud => {
        const targetId = hud.getAttribute("data-scroll-element");
        const scrollContainer = document.getElementById(targetId);
        if (!scrollContainer) return;

        const thumb = hud.querySelector(".scroll-progress-thumb");

        const updateThumb = () => {
            const scrollWidth = scrollContainer.scrollWidth;
            const clientWidth = scrollContainer.clientWidth;
            const maxScroll = scrollWidth - clientWidth;
            
            if (maxScroll <= 10) {
                hud.classList.add("hidden");
                return;
            }
            hud.classList.remove("hidden");

            const scrollLeft = scrollContainer.scrollLeft;
            const percent = (scrollLeft / maxScroll) * 100;
            const thumbWidth = Math.max(15, (clientWidth / scrollWidth) * 100);

            thumb.style.width = `${thumbWidth}%`;
            const leftOffset = (percent / 100) * (100 - thumbWidth);
            thumb.style.left = `${leftOffset}%`;
        };

        // Touch & custom wheel scroll updates
        scrollContainer.addEventListener("scroll", updateThumb, { passive: true });
        window.addEventListener("resize", updateThumb, { passive: true });
        
        // Initial setup sync
        setTimeout(updateThumb, 400);
    });
    
    // Build Donut Legend and setup conic gradient dynamically
    const donutLegendEl = document.getElementById("donut-chart-legend");
    donutLegendEl.innerHTML = donutSlices.map(item => `<span class="legend-dot before:bg-[${item.color}]">${item.title}</span>`).join('');
    
    const donutEl = document.querySelector(".js-donut-chart");
    const conicString = donutSlices.map((slice, index, arr) => {
        const prevMax = index === 0 ? "0" : ((arr[index - 1].max / 360) * 100) + "%";
        const maxPercent = ((slice.max / 360) * 100) + "%";
        return `${slice.color}_${prevMax}_${maxPercent}`;
    }).join(",_");
    
    donutEl.setAttribute("data-conic", conicString);
})();

const streamingList = document.querySelector("#streaming-list");
const loadMoreBtn = document.getElementById("load-more-btn");
const jumpLinks = document.querySelectorAll("[data-scroll-target]");
const tabButtons = document.querySelectorAll(".filter-pill");

let currentDisplayCount = 5;
let currentCategory = "Overall";

function renderStreamingList(dataKey, displayCount) {
    const shows = tabData[dataKey] || tabData["Overall"];
    if (streamingList) {
        const visibleShows = shows.slice(0, displayCount);
        streamingList.innerHTML = visibleShows
            .map(
                (show, index) => `
                    <article class="show-item">
                        <div class="show-meta">
                            <div class="show-poster-wrap">
                                <span class="show-rank">${index + 1}</span>
                                <img src="${show.poster}" alt="${show.title} Poster" class="show-poster" onerror="this.src='./assets/images/posters/bridgerton.jpg'" />
                            </div>
                            <div class="flex flex-col items-between">
                                <p class="show-name">${show.title}</p>
                                <p class="show-service">${show.service}</p>
                                <p class="show-episodes">${show.episodes}</p>
                            </div>
                            <div class="show-minutes-container col-span-2 w-full">
                                <p class="show-minutes">Minutes Viewed in Millions:</p>
                                <div class="show-bar"><span class="js-grow-w" data-target="${show.width}" style="width: 0%; transition: width 1s cubic-bezier(0.16, 1, 0.3, 1);">${show.minutes}</span></div>
                            </div>
                        </div>
                    </article>
                `
            )
            .join("");
            
        // Handle horizontal bar animations immediately if we are already scrolled to and viewing the tabs
        setTimeout(() => {
            if (streamingList) {
                const rect = streamingList.getBoundingClientRect();
                const isVisible = rect.top < window.innerHeight && rect.bottom > 0;
                if (isVisible) {
                    streamingList.querySelectorAll(".js-grow-w").forEach(span => {
                        span.style.width = span.getAttribute("data-target");
                        span.classList.remove("js-grow-w");
                    });
                }
            }
        }, 50);

        // Handle Load More button visibility
        if (loadMoreBtn) {
            const listContainer = streamingList.parentElement;
            if (displayCount >= shows.length) {
                loadMoreBtn.style.display = "none";
                // Expand container to take up the space previously used by the button (~4.25rem)
                listContainer.style.maxHeight = "1091px"; 
            } else {
                loadMoreBtn.style.display = "block";
                // Revert to tailwind class max-h-[26rem]
                listContainer.style.maxHeight = ""; 
            }
        }
    }
}

tabButtons.forEach(button => {
    button.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        
        // Remove active class from all buttons
        tabButtons.forEach(btn => {
            btn.classList.remove("filter-pill-active");
        });
        
        // Add to clicked button
        button.classList.add("filter-pill-active");
        
        // Reset display count and category
        currentCategory = button.textContent.trim();
        currentDisplayCount = 5;
        
        // Render data
        renderStreamingList(currentCategory, currentDisplayCount);
    });
});

if (loadMoreBtn) {
    loadMoreBtn.addEventListener("click", () => {
        const originalText = loadMoreBtn.innerText;
        loadMoreBtn.innerText = "Loading...";
        loadMoreBtn.disabled = true;
        
        // Simulate network loading
        setTimeout(() => {
            currentDisplayCount += 5;
            renderStreamingList(currentCategory, currentDisplayCount);
            
            // Revert button state
            loadMoreBtn.innerText = "Load More";
            loadMoreBtn.disabled = false;
        }, 800);
    });
}

// Initial render handled synchronously now
renderStreamingList(currentCategory, currentDisplayCount);

// Ensure the intersection observer runs when elements become visible
const observerOptions = {
    root: null,
    rootMargin: "0px",
    threshold: 0.1
};

const activeCountAnimations = new WeakMap();

const formatAnimatedValue = (value, decimals = 0) => {
    if (decimals > 0) {
        return Number(value).toLocaleString("en-US", {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        });
    }

    return Math.floor(value).toLocaleString("en-US");
};

const animateValue = (obj, start, end, duration, prefix = "", suffix = "", decimals = 0) => {
    const existingAnimation = activeCountAnimations.get(obj);
    if (existingAnimation) {
        window.cancelAnimationFrame(existingAnimation);
    }

    obj.innerHTML = prefix + formatAnimatedValue(start, decimals) + suffix;

    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        
        let current = progress * (end - start) + start;
        const displayValue = formatAnimatedValue(current, decimals);

        obj.innerHTML = prefix + displayValue + suffix;
        if (progress < 1) {
            const nextFrame = window.requestAnimationFrame(step);
            activeCountAnimations.set(obj, nextFrame);
        } else {
            activeCountAnimations.delete(obj);
        }
    };

    const firstFrame = window.requestAnimationFrame(step);
    activeCountAnimations.set(obj, firstFrame);
};

const animateCountUpElement = (el, start = 0) => {
    const target = parseFloat(el.getAttribute("data-target"));
    const prefix = el.getAttribute("data-prefix") || "";
    const suffix = el.getAttribute("data-suffix") || "";
    const decimals = parseInt(el.getAttribute("data-decimals")) || 0;

    animateValue(el, start, target, 2000, prefix, suffix, decimals);
};

const statsObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const section = entry.target;

            // 1. Animate Numbers
            section.querySelectorAll(".js-count-up").forEach(el => {
                animateCountUpElement(el);
                // Remove class to prevent accidental re-runs
                el.classList.remove("js-count-up");
            });
            
            // 2. Animate Vertical Bars (height)
            section.querySelectorAll(".js-grow-h").forEach(el => {
                const targetHeight = el.getAttribute("data-target");
                setTimeout(() => {
                    el.style.height = targetHeight;
                }, 100);
                el.classList.remove("js-grow-h");
            });

            // 3. Animate Horizontal Bars (width)
            section.querySelectorAll(".js-grow-w").forEach(el => {
                const targetWidth = el.getAttribute("data-target");
                setTimeout(() => {
                    el.style.width = targetWidth;
                }, 100);
                el.classList.remove("js-grow-w");
            });
            
            // 4. Animate Pie Chart (conic gradient)
            // Using a CSS mask to sweep the pie chart into view
            section.querySelectorAll(".js-grow-pie").forEach(el => {
                // Tailwind passes underscores in our data-conic, replace with spaces for valid CSS
                const finalConicStr = el.getAttribute("data-conic").replaceAll('_', ' ');
                
                // Mount the pie gradient behind the scenes
                el.style.background = `conic-gradient(${finalConicStr})`;
                
                let currentAngle = 0;
                let duration = 1500; // ms
                let intervalTime = 16; // ~60fps
                
                let sweep = setInterval(() => {
                    currentAngle += (360 / (duration / intervalTime));
                    if (currentAngle >= 360) {
                        currentAngle = 360;
                        clearInterval(sweep);
                        // At the very end, clear the mask constraints
                        el.style.webkitMaskImage = 'none';
                        el.style.maskImage = 'none';
                        el.classList.remove("js-grow-pie");
                    } else {
                        // Creating a swept mask effect using standard conic-gradient masking
                        const mask = `conic-gradient(black ${currentAngle}deg, transparent 0deg)`;
                        el.style.webkitMaskImage = mask;
                        el.style.maskImage = mask;
                    }
                }, intervalTime);
            });

            // Stop observing this entire section so it only triggers once
            observer.unobserve(section);
        }
    });
}, observerOptions);

// Attach observer to the parent sections/panels instead of individual elements
document.querySelectorAll("section, .panel, article").forEach(section => {
    if (section.querySelector(".js-count-up, .js-grow-h, .js-grow-pie, .js-grow-w")) {
        statsObserver.observe(section);
    }
});

// Fan Insights refresh behavior has been replaced with the flip layout handled dynamically above.

// --- Chart Overlay / Tooltip Logic ---
const overlay = document.getElementById("chart-overlay");
const overlayBox = document.getElementById("chart-overlay-box");
const overlayBackdrop = document.getElementById("chart-overlay-backdrop");
const overlayClose = document.getElementById("chart-overlay-close");

const titleEl = document.getElementById("chart-overlay-title");
const dotEl = document.getElementById("chart-overlay-dot");
const percentEl = document.getElementById("chart-overlay-percent");
const logoEl = document.getElementById("chart-overlay-logo");
const logoContainerEl = document.getElementById("chart-overlay-logo-container");
const breakdownEl = document.getElementById("chart-overlay-breakdown");

let isMobile = window.innerWidth < 640;
window.addEventListener("resize", () => {
    isMobile = window.innerWidth < 640;
    // Hide overlay on resize to reset state cleanly
    hideOverlay();
});

function showOverlay(el, event) {
    const type = el.getAttribute("data-type");
    const title = el.getAttribute("data-title");
    const color = el.getAttribute("data-color");
    const percent = el.getAttribute("data-percent");

    // Populate data
    titleEl.textContent = title;
    dotEl.style.backgroundColor = color;
    percentEl.textContent = percent;
    
    // It's a bar
    const logoSrc = el.getAttribute("data-logo");
    if (logoSrc) {
        logoEl.src = logoSrc;
        logoContainerEl.classList.remove("hidden");
    } else {
        logoContainerEl.classList.add("hidden");
    }
    breakdownEl.classList.add("hidden");

    if (!isMobile) {
        // Desktop: Position as a tooltip above the bar
        const rect = el.getBoundingClientRect();
        // Calculate center of the bar, then position the box above it
        const top = rect.top;
        const left = rect.left + (rect.width / 2);
        
        // Remove fixed center alignments for mobile, apply raw pixels
        overlayBox.style.marginTop = "-15px"; // Gap above the bar
        overlayBox.style.top = `${top}px`;
        overlayBox.style.left = `${left}px`;
        
        // Make it visible to hover events
        overlay.classList.remove("pointer-events-none");
        overlay.classList.add("opacity-100");
        
        // Fade in box
        overlayBox.classList.remove("opacity-0", "translate-y-4", "sm:translate-y-0");
        overlayBox.classList.add("opacity-100");
    } else {
        // Mobile: Show as fixed modal center screen
        overlayBox.style.top = "";
        overlayBox.style.left = "";
        overlayBox.style.marginTop = "";
        
        // Enable pointer events on wrapper
        overlay.classList.remove("pointer-events-none");
        overlay.classList.remove("sm:pointer-events-none");
        
        // Fade in wrapper and backdrop
        overlay.classList.add("opacity-100", "pointer-events-auto");
        
        // Slide up modal box
        overlayBox.classList.remove("opacity-0", "translate-y-4");
        overlayBox.classList.add("opacity-100", "translate-y-0");
    }
}

function hideOverlay() {
    overlay.classList.remove("opacity-100", "pointer-events-auto");
    overlay.classList.add("opacity-0", "pointer-events-none", "sm:pointer-events-none");
    
    overlayBox.classList.remove("opacity-100", "translate-y-0");
    overlayBox.classList.add("opacity-0", "translate-y-4", "sm:translate-y-0");
}

document.querySelectorAll(".js-chart-trigger").forEach(trigger => {
    // Desktop hover
    trigger.addEventListener("mouseenter", (e) => {
        if (!isMobile) showOverlay(trigger, e);
    });
    trigger.addEventListener("mouseleave", () => {
        if (!isMobile) hideOverlay();
    });
    
    // Mobile click
    trigger.addEventListener("click", (e) => {
        if (isMobile) showOverlay(trigger, e);
    });
});

document.querySelectorAll(".js-donut-chart").forEach(donut => {
    // Slices are populated by the fetch config now
    // We use `donutSlices` variable from global scope

    function handleDonutHover(e) {
        const rect = donut.getBoundingClientRect();
        
        // Find pointer coords robustly
        let clientX = e.clientX;
        let clientY = e.clientY;
        
        const x = clientX - rect.left - (rect.width / 2);
        const y = clientY - rect.top - (rect.height / 2);
        const distance = Math.sqrt(x * x + y * y);
        
        // Check if hitting the hollow center (radius 56px) or outside bounds (radius 144px)
        if (distance < 56 || distance > 144) {
            if (!isMobile) hideOverlay();
            return;
        }

        // Convert trig angles to full 360 degree coordinates, offset dead top by +90deg
        let angle = (Math.atan2(y, x) * (180 / Math.PI) + 90) % 360;
        if (angle < 0) angle += 360;

        const activeSlice = donutSlices.find(s => angle >= s.min && angle <= s.max);
        if (!activeSlice) return;

        // Apply dynamic overlay payload
        titleEl.textContent = activeSlice.title;
        dotEl.style.backgroundColor = activeSlice.color;
        percentEl.textContent = activeSlice.percent;
        logoContainerEl.classList.add("hidden");
        
        // Only Streaming slice has the sub-breakdown list UI
        if (activeSlice.hasBreakdown && activeSlice.breakdown) {
            breakdownEl.classList.remove("hidden");
            breakdownEl.innerHTML = activeSlice.breakdown.map(b => `
                <div class="flex items-center gap-5">
                    <span class="text-white text-sm w-8">${b.percent}</span>
                    <img src="${b.logo}" alt="${b.alt}" class="${b.logoClass} object-contain brightness-0 invert" />
                </div>
            `).join("");
        } else {
            breakdownEl.classList.add("hidden");
        }

        // Display mechanics
        if (!isMobile) {
            const top = rect.top;
            const left = rect.left + (rect.width / 2);
            overlayBox.style.marginTop = "-15px";
            overlayBox.style.top = `${top}px`;
            overlayBox.style.left = `${left}px`;
            overlay.classList.remove("pointer-events-none");
            overlay.classList.add("opacity-100");
            overlayBox.classList.remove("opacity-0", "translate-y-4", "sm:translate-y-0");
            overlayBox.classList.add("opacity-100");
        } else {
            overlayBox.style.top = "";
            overlayBox.style.left = "";
            overlayBox.style.marginTop = "";
            overlay.classList.remove("pointer-events-none", "sm:pointer-events-none");
            overlay.classList.add("opacity-100", "pointer-events-auto");
            overlayBox.classList.remove("opacity-0", "translate-y-4");
            overlayBox.classList.add("opacity-100", "translate-y-0");
        }
    }

    donut.addEventListener("mousemove", (e) => {
        if (!isMobile) handleDonutHover(e);
    });
    donut.addEventListener("mouseleave", () => {
        if (!isMobile) hideOverlay();
    });
    donut.addEventListener("click", (e) => {
        if (isMobile) handleDonutHover(e);
    });
});

// Mobile close behaviors
overlayBackdrop.addEventListener("click", hideOverlay);
overlayClose.addEventListener("click", hideOverlay);

// --- Drag-to-Scroll & Horizontal Mousewheel support for Top Streaming Shows Tabs ---
const setupTabContainerScroll = () => {
    const container = document.querySelector("#streaming-shows .overflow-x-auto");
    if (!container) return;

    let isDown = false;
    let startX;
    let scrollLeft;

    container.addEventListener("mousedown", (e) => {
        isDown = true;
        startX = e.pageX - container.offsetLeft;
        scrollLeft = container.scrollLeft;
        container.style.cursor = "grabbing";
    });

    container.addEventListener("mouseleave", () => {
        isDown = false;
        container.style.cursor = "grab";
    });

    container.addEventListener("mouseup", () => {
        isDown = false;
        container.style.cursor = "grab";
    });

    container.addEventListener("mousemove", (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - container.offsetLeft;
        const walk = (x - startX) * 2; // scroll-fast multiplier
        container.scrollLeft = scrollLeft - walk;
    });

    // Horizontal wheel scroll redirect
    container.addEventListener("wheel", (e) => {
        if (e.deltaY !== 0) {
            e.preventDefault();
            container.scrollLeft += e.deltaY;
        }
    }, { passive: false });

    // Set cursor styling initially
    container.style.cursor = "grab";
};
setupTabContainerScroll();

// --- Share Button Functionality ---
const shareButton = document.getElementById('share-button');
const shareOverlay = document.getElementById('share-overlay');
const closeOverlayBtn = document.getElementById('close-overlay');
const copyLinkBtn = document.getElementById('copy-link-btn');
const emailLinkBtn = document.getElementById('email-link-btn');
const copyNotification = document.getElementById('copy-notification');

if (shareButton && shareOverlay) {
    // Dynamically set native mailto link for robust execution
    if (emailLinkBtn) {
        const url = window.location.href;
        const subject = encodeURIComponent(document.title);
        const body = encodeURIComponent(`Check out this page: ${url}`);
        emailLinkBtn.setAttribute('href', `mailto:?subject=${subject}&body=${body}`);
    }

    shareButton.addEventListener('click', () => {
        shareOverlay.classList.remove('hidden');
        shareOverlay.classList.add('flex');
    });

    closeOverlayBtn.addEventListener('click', () => {
        shareOverlay.classList.add('hidden');
        shareOverlay.classList.remove('flex');
    });

    shareOverlay.addEventListener('click', (e) => {
        if (e.target === shareOverlay) {
            shareOverlay.classList.add('hidden');
            shareOverlay.classList.remove('flex');
        }
    });

    copyLinkBtn.addEventListener('click', () => {
        const url = window.location.href;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(url)
                .then(() => showCopySuccess())
                .catch(() => fallbackCopy(url));
        } else {
            fallbackCopy(url);
        }
    });

    function fallbackCopy(text) {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.top = "0";
        textArea.style.left = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            showCopySuccess();
        } catch (err) {
            console.error('Fallback copy failed:', err);
        }
        document.body.removeChild(textArea);
    }

    function showCopySuccess() {
        if (copyNotification) {
            copyNotification.classList.remove('hidden');
            setTimeout(() => {
                copyNotification.classList.add('hidden');
            }, 3000);
        }
    }
}
