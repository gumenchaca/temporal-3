const configData = {
    "streamingShows": {
        "Overall": [
            { "title": "Stranger Things", "service": "Netflix", "episodes": "42 Episodes", "minutes": "20,751", "width": "100%", "poster": "./assets/images/posters/stranger_things.jpg" },
            { "title": "Bridgerton", "service": "Netflix", "episodes": "32 Episodes", "minutes": "14,948", "width": "72%", "poster": "./assets/images/posters/bridgerton.jpg" },
            { "title": "The Pitt", "service": "HBO Max", "episodes": "27 Episodes", "minutes": "13,670", "width": "66%", "poster": "./assets/images/posters/the_pitt.jpg" },
            { "title": "Bluey", "service": "Disney+", "episodes": "154 Episodes", "minutes": "11,295", "width": "54%", "poster": "./assets/images/posters/bluey.jpg" },
            { "title": "Greys Anatomy", "service": "Hulu/Netflix", "episodes": "464 Episodes", "minutes": "10,239", "width": "49%", "poster": "./assets/images/posters/greys_anatomy.jpg" },
            { "title": "Big Bang Theory", "service": "HBO Max", "episodes": "281 Episodes", "minutes": "9,939", "width": "48%", "poster": "./assets/images/posters/the_big_bang_theory.jpg" },
            { "title": "Landman", "service": "Paramount+", "episodes": "20 Episodes", "minutes": "9,921", "width": "48%", "poster": "./assets/images/posters/landman.png" },
            { "title": "Lincoln Lawyer", "service": "Netflix", "episodes": "40 Episodes", "minutes": "8,787", "width": "42%", "poster": "./assets/images/posters/lincoln_lawyer.png" },
            { "title": "Spongebob Squarepants", "service": "Paramount+", "episodes": "336 Episodes", "minutes": "8,700", "width": "42%", "poster": "./assets/images/posters/spongebob_squarepants.jpg" },
            { "title": "The Closer", "service": "Netflix / Peacock / Pluto TV", "episodes": "111 Episodes", "minutes": "8,271", "width": "40%", "poster": "./assets/images/posters/the_closer.jpg", "missingThumbnail": true }
        ],
        "Original": [
            { "title": "Stranger Things", "service": "Netflix", "episodes": "42 Episodes", "minutes": "20,751", "width": "100%", "poster": "./assets/images/posters/stranger_things.jpg" },
            { "title": "Bridgerton", "service": "Netflix", "episodes": "32 Episodes", "minutes": "14,948", "width": "72%", "poster": "./assets/images/posters/bridgerton.jpg" },
            { "title": "The Pitt", "service": "HBO Max", "episodes": "27 Episodes", "minutes": "13,670", "width": "66%", "poster": "./assets/images/posters/the_pitt.jpg" },
            { "title": "Landman", "service": "Paramount+", "episodes": "20 Episodes", "minutes": "9,921", "width": "48%", "poster": "./assets/images/posters/landman.png" },
            { "title": "The Lincoln Lawyer", "service": "Netflix", "episodes": "40 Episodes", "minutes": "8,787", "width": "42%", "poster": "./assets/images/posters/lincoln_lawyer.png" },
            { "title": "His & Hers", "service": "Netflix", "episodes": "8 Episodes", "minutes": "7,854", "width": "38%", "poster": "./assets/images/posters/his_and_hers.jpg", "missingThumbnail": true },
            { "title": "Fallout", "service": "Prime Video", "episodes": "8 Episodes", "minutes": "7,120", "width": "34%", "poster": "./assets/images/posters/fallout.jpg", "missingThumbnail": true },
            { "title": "The Night Agent", "service": "Netflix", "episodes": "10 Episodes", "minutes": "6,650", "width": "32%", "poster": "./assets/images/posters/the_night_agent.jpg", "missingThumbnail": true },
            { "title": "The Traitors", "service": "Peacock", "episodes": "21 Episodes", "minutes": "5,980", "width": "29%", "poster": "./assets/images/posters/the_traitors.jpg", "missingThumbnail": true },
            { "title": "Love is Blind", "service": "Netflix", "episodes": "84 Episodes", "minutes": "5,430", "width": "26%", "poster": "./assets/images/posters/love_is_blind.jpg", "missingThumbnail": true }
        ],
        "Acquired": [
            { "title": "Bluey", "service": "Disney+", "episodes": "154 Episodes", "minutes": "11,295", "width": "100%", "poster": "./assets/images/posters/bluey.jpg" },
            { "title": "Greys Anatomy", "service": "Hulu/Netflix", "episodes": "464 Episodes", "minutes": "10,239", "width": "90%", "poster": "./assets/images/posters/greys_anatomy.jpg" },
            { "title": "Big Bang Theory", "service": "HBO Max", "episodes": "281 Episodes", "minutes": "9,939", "width": "88%", "poster": "./assets/images/posters/the_big_bang_theory.jpg" },
            { "title": "Spongebob Squarepants", "service": "Paramount+", "episodes": "336 Episodes", "minutes": "8,700", "width": "77%", "poster": "./assets/images/posters/spongebob_squarepants.jpg" },
            { "title": "The Closer", "service": "Netflix / Peacock / Pluto TV", "episodes": "111 Episodes", "minutes": "8,271", "width": "73%", "poster": "./assets/images/posters/the_closer.jpg", "missingThumbnail": true },
            { "title": "Family Guy", "service": "Hulu/Netflix", "episodes": "424 Episodes", "minutes": "7,950", "width": "70%", "poster": "./assets/images/posters/family_guy.jpg", "missingThumbnail": true },
            { "title": "Bob's Burgers", "service": "Hulu", "episodes": "274 Episodes", "minutes": "7,100", "width": "63%", "poster": "./assets/images/posters/bobs_burgers.jpg", "missingThumbnail": true },
            { "title": "Law & Order", "service": "Peacock", "episodes": "500 Episodes", "minutes": "6,450", "width": "57%", "poster": "./assets/images/posters/law_and_order.jpg", "missingThumbnail": true },
            { "title": "Paw Patrol", "service": "Paramount+", "episodes": "250 Episodes", "minutes": "5,900", "width": "52%", "poster": "./assets/images/posters/paw_patrol.jpg", "missingThumbnail": true },
            { "title": "The Rookie", "service": "Hulu/Netflix", "episodes": "108 Episodes", "minutes": "5,350", "width": "47%", "poster": "./assets/images/posters/the_rookie.jpg", "missingThumbnail": true }
        ],
        "Kids Movies": [
            { "title": "Zootopia 2", "service": "Disney+", "episodes": "1 Episode", "minutes": "3,669", "width": "100%", "poster": "./assets/images/posters/zootopia.jpg" },
            { "title": "KPop Demon Hunters", "service": "Netflix", "episodes": "1 Episode", "minutes": "3,490", "width": "95%", "poster": "./assets/images/posters/kpop_demon_hunters.jpg" },
            { "title": "Zootopia", "service": "Disney+", "episodes": "1 Episode", "minutes": "2,499", "width": "68%", "poster": "./assets/images/posters/zootopia.jpg" },
            { "title": "A Minecraft Movie", "service": "HBO Max", "episodes": "1 Episode", "minutes": "1,554", "width": "42%", "poster": "./assets/images/posters/a_minecraft_movie.jpg" },
            { "title": "Frozen", "service": "Disney+", "episodes": "1 Episode", "minutes": "1,415", "width": "38%", "poster": "./assets/images/posters/frozen.jpg" },
            { "title": "Cars", "service": "Disney+", "episodes": "1 Episode", "minutes": "1,372", "width": "37%", "poster": "./assets/images/posters/cars.jpg" },
            { "title": "The Bad Guys 2", "service": "Netflix", "episodes": "1 Episode", "minutes": "1,220", "width": "33%", "poster": "./assets/images/posters/the_bad_guys_2.jpg", "missingThumbnail": true },
            { "title": "Super Mario Bros. Movie", "service": "Peacock/Netflix", "episodes": "1 Episode", "minutes": "1,110", "width": "30%", "poster": "./assets/images/posters/super_mario_bros_movie.jpg", "missingThumbnail": true },
            { "title": "Rio", "service": "Disney+", "episodes": "1 Episode", "minutes": "1,020", "width": "28%", "poster": "./assets/images/posters/rio.jpg", "missingThumbnail": true },
            { "title": "Paw Patrol: The Movie", "service": "Paramount+", "episodes": "1 Episode", "minutes": "950", "width": "26%", "poster": "./assets/images/posters/paw_patrol_the_movie.jpg", "missingThumbnail": true }
        ],
        "Top Movies - General Audience": [
            { "title": "The RIP", "service": "Netflix", "episodes": "1 Episode", "minutes": "4,009", "width": "100%", "poster": "./assets/images/posters/the_rip.jpg" },
            { "title": "War Machine", "service": "Netflix", "episodes": "1 Episode", "minutes": "2,720", "width": "68%", "poster": "./assets/images/posters/war_machine.jpg" },
            { "title": "The Wrecking Crew", "service": "Prime Video", "episodes": "1 Episode", "minutes": "2,652", "width": "66%", "poster": "./assets/images/posters/the_wrecking_crew.jpg" },
            { "title": "Jurassic World Rebirth", "service": "Peacock / Netflix", "episodes": "1 Episode", "minutes": "2,609", "width": "65%", "poster": "./assets/images/posters/jurrasic_world_rebirth.jpg" },
            { "title": "Sinners", "service": "HBO Max", "episodes": "1 Episode", "minutes": "2,003", "width": "50%", "poster": "./assets/images/posters/sinners.jpg" },
            { "title": "People We Meet on Vacation", "service": "Netflix", "episodes": "1 Episode", "minutes": "1,850", "width": "46%", "poster": "./assets/images/posters/people_we_meet_on_vacation.jpg", "missingThumbnail": true },
            { "title": "Joes's College Road Trip", "service": "Disney+", "episodes": "1 Episode", "minutes": "1,680", "width": "42%", "poster": "./assets/images/posters/joes_college_road_trip.jpg", "missingThumbnail": true },
            { "title": "One Battle After Another", "service": "Netflix", "episodes": "1 Episode", "minutes": "1,490", "width": "37%", "poster": "./assets/images/posters/one_battle_after_another.jpg", "missingThumbnail": true },
            { "title": "How To Train Your Dragon", "service": "Peacock", "episodes": "1 Episode", "minutes": "1,320", "width": "33%", "poster": "./assets/images/posters/how_to_train_your_dragon.jpg", "missingThumbnail": true },
            { "title": "The Running Man", "service": "Paramount", "episodes": "1 Episode", "minutes": "1,210", "width": "30%", "poster": "./assets/images/posters/the_running_man.jpg", "missingThumbnail": true }
        ]
    },
    "donutSlices": [
        { "title": "Samsung", "color": "#39C4C4", "percent": "23.0%", "min": 0, "max": 82.8, "hasBreakdown": false },
        { "title": "TCL", "color": "#00B0D6", "percent": "14.0%", "min": 82.8, "max": 133.2, "hasBreakdown": false },
        { "title": "Vizio", "color": "#2E96DA", "percent": "12.3%", "min": 133.2, "max": 177.48, "hasBreakdown": false },
        { "title": "LG", "color": "#6BE0AA", "percent": "11.1%", "min": 177.48, "max": 217.44, "hasBreakdown": false },
        { "title": "ONN", "color": "#C6F481", "percent": "9.3%", "min": 217.44, "max": 250.92, "hasBreakdown": false },
        { "title": "Hisense", "color": "#F9F871", "percent": "9.2%", "min": 250.92, "max": 284.04, "hasBreakdown": false },
        { "title": "Insignia", "color": "#008E8E", "percent": "5.2%", "min": 284.04, "max": 302.76, "hasBreakdown": false },
        { "title": "Sony", "color": "#BFFCFB", "percent": "3.6%", "min": 302.76, "max": 315.72, "hasBreakdown": false },
        { "title": "Philips", "color": "#95B1B0", "percent": "3.1%", "min": 315.72, "max": 326.88, "hasBreakdown": false },
        { "title": "Toshiba", "color": "#D2EBE2", "percent": "2.0%", "min": 326.88, "max": 334.08, "hasBreakdown": false },
        { "title": "Sharp", "color": "#398770", "percent": "1.2%", "min": 334.08, "max": 338.4, "hasBreakdown": false },
        { "title": "Other", "color": "#95F7B1", "percent": "6.0%", "min": 338.4, "max": 360, "hasBreakdown": false }
    ],
    "lineChart": {
        "cohorts": [
            { "id": "p2_17", "label": "Persons 2 - 17", "color": "#503eff" },
            { "id": "p18_34", "label": "Persons 18 - 34", "color": "#ff4af4" },
            { "id": "p35_49", "label": "Persons 35 - 49", "color": "#bb6efe" },
            { "id": "p50_64", "label": "Persons 50 - 64", "color": "#b400b4" },
            { "id": "p65_99", "label": "Persons 65 - 99", "color": "#e2bdff" }
        ],
        "quarters": ["4Q23", "1Q24", "2Q24", "3Q24", "4Q24", "1Q25", "2Q25", "3Q25", "4Q25", "1Q26"],
        "data": [
            { "quarter": "4Q23", "p2_17": 19808, "p18_34": 41017, "p35_49": 48381, "p50_64": 47290, "p65_99": 35244 },
            { "quarter": "1Q24", "p2_17": 24163, "p18_34": 45902, "p35_49": 59677, "p50_64": 59759, "p65_99": 53287 },
            { "quarter": "2Q24", "p2_17": 24118, "p18_34": 64241, "p35_49": 66574, "p50_64": 77000, "p65_99": 57487 },
            { "quarter": "3Q24", "p2_17": 30169, "p18_34": 54998, "p35_49": 82232, "p50_64": 87915, "p65_99": 68698 },
            { "quarter": "4Q24", "p2_17": 33573, "p18_34": 59778, "p35_49": 107073, "p50_64": 107420, "p65_99": 80241 },
            { "quarter": "1Q25", "p2_17": 36620, "p18_34": 60426, "p35_49": 112005, "p50_64": 113731, "p65_99": 80616 },
            { "quarter": "2Q25", "p2_17": 33303, "p18_34": 72146, "p35_49": 98007, "p50_64": 99964, "p65_99": 87295 },
            { "quarter": "3Q25", "p2_17": 32638, "p18_34": 53179, "p35_49": 86931, "p50_64": 105897, "p65_99": 83340 },
            { "quarter": "4Q25", "p2_17": 27588, "p18_34": 37123, "p35_49": 77581, "p50_64": 95134, "p65_99": 70861 },
            { "quarter": "1Q26", "p2_17": 21436, "p18_34": 29872, "p35_49": 58208, "p50_64": 86426, "p65_99": 64836 }
        ]
    },
    "behaviorInsights": {
        "mainStat": {
            "target": 73,
            "prefix": "",
            "suffix": "%",
            "decimals": 0,
            "copy": "Of U.S. world cup fans find brand sponsors more appealing than <span class=\"whitespace-nowrap\">non-sponsors</span>"

        },
        "worldCupBookings": {
            "target": 62.5,
            "prefix": "",
            "suffix": "M",
            "decimals": 1,
            "copy": "U.S. soccer fans"
        },
        "adr": {
            "target": 64,
            "prefix": "",
            "suffix": "%",
            "decimals": 0,
            "copy": "Soccer interest shaped by social <br> <span class=\"text-[10px]\">(64% of U.S. soccer fans)</span>"
        },
        "conversionRate": {
            "target": 60,
            "prefix": "",
            "suffix": "%",
            "decimals": 0,
            "copy": "Watch soccer out-of-home <br> <span class=\"text-[10px]\">(60% of U.S. soccer fans)</span>"
        },
        "campaignImpressions": {
            "target": 33,
            "prefix": "",
            "suffix": "",
            "decimals": 0,
            "copy": "Median age of U.S. soccer fan"
        }
    },
    "fanInsights": [
        {
            "title": "NBA",
            "front": "Top 5 most-watched NBA Teams",
            "back": `1. Oklahoma City Thunder <br> 2. Los Angeles Lakers <br> 3. New York Knicks <br> 4. Houston Rockets <br> 5. Denver Nuggets`
        },
        {
            "title": "NHL",
            "front": "Cultural moments propel NHL",
            "back": "77% increase in average viewership for round one of the NHL playoffs."
        },
        {
            "title": "INDYCAR",
            "front": "Indy 500 Hits 17-Year High",
            "back": "The 2025 Indianapolis 500–the series' premier race–averaged over seven million viewers, the most in 17 years."
        },
        {
            "title": "GOLF",
            "front": "PGA Golf's Upward Momentum",
            "back": "2025 growth continues into 2026, with Tour viewership up 21% so far versus the same period last year."
        }
    ],
    "sources": [
        { "title": "Source 1", "description": "Nielsen National TV Panel, viewing in 1Q 2026. Homes that have more than one smart TV brand will count for each brand." },
        { "title": "Source 2", "description": "Nielsen Streaming Platform Ratings" },
        { "title": "Source 3", "description": "FIFA - Nielsen North American Fandom Report" },
        { "title": "Source 4", "description": "Nielsen Streaming Content Ratings (Amazon Prime Video, Apple TV, Disney+, HBO Max, Hulu, Netflix, Paramount+, Peacock, Starz, Pluto TV). Nielsen National TV Panel (USA). Viewing on television." },
        { "title": "Source 5", "description": "Nielsen's Top of Sports, June 2026" },
    ]
};