# Landing Page Structure

This scaffold is set up for a static Tailwind CDN landing page.

## Entry file

- `./index.html` - main desktop and mobile layout shell.

## Asset paths

- `./assets/css/styles.css` - custom fonts, reusable component styles, non-Tailwind polish.
- `./assets/js/main.js` - small interaction or data-render scripts.
- `./assets/images/hero/` - hero backgrounds, grain textures, top fold artwork.
- `./assets/images/logos/` - Nielsen, Amazon, FIFA, sponsor lockups.
- `./assets/images/cards/` - section-specific imagery used in stat cards.
- `./assets/images/posters/` - streaming show thumbnails.
- `./assets/icons/` - arrows, refresh icons, small UI marks as SVG/PNG.
- `./assets/fonts/bebas-neue/` - display font files for headings.
- `./assets/fonts/inter/` - body font files.

## Recommended image names

- `./assets/images/hero/hero-desktop.webp`
- `./assets/images/hero/hero-mobile.webp`
- `./assets/images/hero/hero-grain.png`
- `./assets/images/logos/logo-strip.svg`
- `./assets/images/cards/behavior-insight-bg.webp`
- `./assets/images/cards/world-cup-insights-bg.webp`
- `./assets/images/posters/stranger-things.webp`

## Fonts used by this scaffold

- `./assets/fonts/lemon/Lemon-Regular.woff2`
- `./assets/fonts/lemon/Lemon-Regular.woff`
- `./assets/fonts/space-mono/SpaceMono-Regular.ttf`
- `./assets/fonts/space-mono/SpaceMono-Bold.ttf`

## Notes

- Tailwind is loaded from the CDN in `index.html`.
- Headings use Lemon and body/UI text uses Space Mono.
- If you swap font filenames, update the `@font-face` paths in `./assets/css/styles.css`.
- If you decide to move from CDN Tailwind to a build setup later, this asset structure still works.