let tabData = {};

// Initialize variables immediately with global configuration from config.js
(function initializeConfig() {
    tabData = configData.streamingShows;

    const brandConfig = configData.brand || {};
    const brandName = brandConfig.name || "Netflix";
    const brandLogo = brandConfig.logo || "";

    document.title = `Nielsen Insights For ${brandName}`;

    const pageDescriptionEl = document.getElementById("page-description");
    if (pageDescriptionEl) {
        pageDescriptionEl.setAttribute("content", `Nielsen Insights For ${brandName}.`);
    }

    const heroBrandLogoEl = document.getElementById("hero-brand-logo");
    if (heroBrandLogoEl) {
        if (brandLogo) {
            heroBrandLogoEl.setAttribute("src", brandLogo);
        }
        heroBrandLogoEl.setAttribute("alt", brandName);
    }

    const footerBrandLogoEl = document.getElementById("footer-brand-logo");
    if (footerBrandLogoEl) {
        if (brandLogo) {
            footerBrandLogoEl.setAttribute("src", brandLogo);
        }
        footerBrandLogoEl.setAttribute("alt", brandName);
    }

    // Build Netflix stacked bar chart with range select and horizontal overflow.
    const roundToNiceStep = (rawStep) => {
        if (!rawStep || rawStep <= 0) {
            return 1;
        }

        const magnitude = 10 ** Math.floor(Math.log10(rawStep));
        const fraction = rawStep / magnitude;

        if (fraction <= 1) return 1 * magnitude;
        if (fraction <= 2) return 2 * magnitude;
        if (fraction <= 2.5) return 2.5 * magnitude;
        if (fraction <= 5) return 5 * magnitude;
        return 10 * magnitude;
    };

    const formatTick = (value) => {
        if (value >= 1000000) {
            const inMillions = value / 1000000;
            return `${Number(inMillions.toFixed(2))}M`;
        }

        if (value >= 1000) {
            return `${Math.round(value / 1000)}k`;
        }

        return `${Math.round(value)}`;
    };

    const getScaledHeightPercent = (val, isPercentage = false) => {
        if (isPercentage) {
            return Math.min(100, Math.max(0, val));
        }
        if (val <= 0) return 0;
        const bandUnit = 100 / 5.5; // Each full band is 1/5.5 of the total height (18.18%)
        
        if (val <= 50000) {
            return (val / 50000) * bandUnit;
        }
        if (val <= 100000) {
            return bandUnit + ((val - 50000) / 50000) * bandUnit;
        }
        if (val <= 200000) {
            return (2 * bandUnit) + ((val - 100000) / 100000) * bandUnit;
        }
        if (val <= 500000) {
            return (3 * bandUnit) + ((val - 200000) / 300000) * bandUnit;
        }
        if (val <= 1000000) {
            return (4 * bandUnit) + ((val - 500000) / 500000) * bandUnit;
        }
        if (val <= 1250000) {
            return (5 * bandUnit) + ((val - 1000000) / 250000) * (0.5 * bandUnit);
        }
        return 100;
    };

    // Generalized setup function for both Netflix charts (cyan and purple)
    const setupOmniStackedChart = (chartConfig, elements) => {
        const { rangeEl, legendEl, yAxisEl, plotEl, subtitleEl, subtitlePrefix } = elements;

        if (!chartConfig || !rangeEl || !legendEl || !yAxisEl || !plotEl) {
            return;
        }

        const isPercentageChart = !!chartConfig.isPercentage;
        const maxY = chartConfig.maxY || 100;
        let activeCohort = "all";
        let hasIntersected = false;

        const getScaledHeightPercentForChart = (val) => {
            if (isPercentageChart) {
                return (val / maxY) * 100;
            }
            return getScaledHeightPercent(val, false);
        };

        const renderChart = (rangeValue) => {
            const selectedRange = chartConfig.ranges.find((item) => item.value === rangeValue) || chartConfig.ranges[0];
            if (!selectedRange) {
                return;
            }

            // Reset active cohort highlight on tab change
            activeCohort = "all";

            const activeLegend = selectedRange.legend || chartConfig.legend || [];
            
            // Build temporary months/series map depending on grouped or non-grouped layout
            let months = [];
            let series = {};
            let groupMeta = null;

            if (selectedRange.isGrouped) {
                activeLegend.forEach(legendItem => {
                    series[legendItem.key] = [];
                });
                groupMeta = [];
                let currentIndex = 0;
                selectedRange.groups.forEach(group => {
                    const startIdx = currentIndex;
                    group.bars.forEach(bar => {
                        months.push(bar.label);
                        activeLegend.forEach(legendItem => {
                            series[legendItem.key].push(bar.series[legendItem.key] || 0);
                        });
                        currentIndex++;
                    });
                    const endIdx = currentIndex - 1;
                    groupMeta.push({ label: group.label, startIdx, endIdx });
                });
            } else {
                months = selectedRange.months;
                series = selectedRange.series;
            }

            const totals = months.map((_, index) => {
                return activeLegend.reduce((sum, item) => {
                    return sum + (Number(series[item.key]?.[index]) || 0);
                }, 0);
            });

            // For percentage charts, the ticks are [100, 80, 60, 40, 20, 0] (or [80, 60, 40, 20, 0] if maxY is 80)
            // For volume charts, they are [1250000, 1000000, 500000, 200000, 100000, 50000, 0]
            const staticTicks = isPercentageChart 
                ? (maxY === 80 ? [80, 60, 40, 20, 0] : [100, 80, 60, 40, 20, 0]) 
                : [1250000, 1000000, 500000, 200000, 100000, 50000, 0];
            yAxisEl.innerHTML = "";

            const gridLines = [];
            staticTicks.forEach((tickVal) => {
                const heightPerc = getScaledHeightPercentForChart(tickVal);
                const topPerc = 100 - heightPerc;

                // Render Y-Tick positioned absolutely to match the non-linear scale and gridlines
                // Don't label or show the gridline/tick for the additional headroom step in volume charts (1.25M)
                if (!isPercentageChart && tickVal === 1250000) {
                    return;
                }

                const tickEl = document.createElement("span");
                tickEl.className = "omni-chart-y-tick absolute right-[0.5rem]";
                tickEl.style.top = `${topPerc}%`;
                tickEl.textContent = isPercentageChart ? `${tickVal}%` : formatTick(tickVal);
                yAxisEl.appendChild(tickEl);

                // Add dashed horizontal helper gridline (omit baseline at 100% top/0 value)
                if (tickVal > 0) {
                    gridLines.push(`<span class="omni-chart-grid-line" style="top:${topPerc}%"></span>`);
                }
            });

            legendEl.innerHTML = activeLegend
                .map((item) => {
                    return `
                        <button type="button" class="omni-chart-legend-item cursor-pointer hover:opacity-100 transition duration-150 flex items-center gap-[0.45rem] focus:outline-none" data-key="${item.key}" aria-label="Highlight ${item.label}">
                            <span class="omni-chart-legend-dot" style="background:${item.color};"></span>
                            <span>${item.label}</span>
                        </button>
                    `;
                })
                .join("");

            let minPlotWidth = 0;
            if (isPercentageChart) {
                if (selectedRange.isGrouped && groupMeta) {
                    const groupCount = groupMeta.length;
                    // Group container is 112px (7rem), gap between groups is 36px (2.25rem), padding is 16px (0.5rem each side)
                    minPlotWidth = (groupCount * 112) + ((groupCount - 1) * 36) + 32;
                } else {
                    const count = months.length;
                    minPlotWidth = (count * 56) + ((count - 1) * 24) + 24;
                }
            } else {
                const count = months.length;
                minPlotWidth = (count * 56) + ((count - 1) * 20) + 24;
            }
            plotEl.style.minWidth = `${minPlotWidth}px`;

            let barsMarkup = "";
            if (selectedRange.isGrouped && groupMeta) {
                // Change height dynamically to fit nested labels
                plotEl.style.height = "20.25rem";
                yAxisEl.style.height = "18rem";

                barsMarkup = groupMeta.map((group) => {
                    const groupBarsMarkup = [];
                    for (let idx = group.startIdx; idx <= group.endIdx; idx++) {
                        const month = months[idx];
                        const monthTotal = totals[idx] || 0;
                        let currentSum = 0;
                        const segments = activeLegend
                            .map((legendItem) => {
                                const value = Number(series[legendItem.key]?.[idx]) || 0;
                                const startVal = currentSum;
                                const endVal = currentSum + value;
                                currentSum = endVal;

                                let startPerc, endPerc, heightPercent;
                                if (isPercentageChart) {
                                    if (chartConfig.maxY) {
                                        startPerc = (startVal / maxY) * 100;
                                        endPerc = (endVal / maxY) * 100;
                                    } else {
                                        startPerc = monthTotal > 0 ? (startVal / monthTotal) * 100 : 0;
                                        endPerc = monthTotal > 0 ? (endVal / monthTotal) * 100 : 0;
                                    }
                                    heightPercent = Math.max(0, endPerc - startPerc);
                                } else {
                                    startPerc = getScaledHeightPercent(startVal, false);
                                    endPerc = getScaledHeightPercent(endVal, false);
                                    heightPercent = Math.max(0, endPerc - startPerc);
                                }

                                const formattedVal = isPercentageChart ? `${value.toFixed(1)}%` : formatTick(value);
                                return `
                                    <span 
                                        class="omni-chart-segment js-chart-trigger cursor-pointer" 
                                        data-height="${heightPercent}" 
                                        style="height:0%; background:${legendItem.color}" 
                                        data-type="bar"
                                        data-cohort="${legendItem.key}"
                                        data-title="${legendItem.label} • ${group.label} ${month}"
                                        data-color="${legendItem.color}"
                                        data-percent="${formattedVal}"
                                        title="${legendItem.label}: ${formattedVal}">
                                    </span>
                                `;
                            })
                            .join("");

                        const formattedTotal = isPercentageChart 
                            ? (chartConfig.maxY ? `${monthTotal.toFixed(1)}%` : "100%") 
                            : formatTick(monthTotal);
                        groupBarsMarkup.push(`
                            <div class="omni-chart-group" style="width: 3rem; height: 18rem; position: relative;">
                                <div class="omni-chart-stack" role="img" aria-label="${month}: ${formattedTotal} total">
                                    ${segments}
                                </div>
                                <span class="omni-chart-month">${month}</span>
                            </div>
                        `);
                    }

                    return `
                        <div class="omni-chart-group-container relative flex flex-col items-center" style="gap: 0.5rem; height: 18rem; flex-shrink: 0; min-width: 7rem;">
                            <div class="flex gap-4 items-end" style="height: 18rem;">
                                ${groupBarsMarkup.join("")}
                            </div>
                            <span class="absolute bottom-[-32px] left-1/2 -translate-x-1/2 text-[11px] font-bold text-slate-300 uppercase tracking-wide whitespace-nowrap leading-none">${group.label}</span>
                        </div>
                    `;
                }).join("");
            } else {
                plotEl.style.height = "19.5rem";
                yAxisEl.style.height = "18rem";

                barsMarkup = months
                    .map((month, monthIndex) => {
                        const monthTotal = totals[monthIndex] || 0;
                        let currentSum = 0;
                        const segments = activeLegend
                            .map((legendItem) => {
                                const value = Number(series[legendItem.key]?.[monthIndex]) || 0;
                                const startVal = currentSum;
                                const endVal = currentSum + value;
                                currentSum = endVal;

                                let startPerc, endPerc, heightPercent;
                                if (isPercentageChart) {
                                    if (chartConfig.maxY) {
                                        startPerc = (startVal / maxY) * 100;
                                        endPerc = (endVal / maxY) * 100;
                                    } else {
                                        startPerc = monthTotal > 0 ? (startVal / monthTotal) * 100 : 0;
                                        endPerc = monthTotal > 0 ? (endVal / monthTotal) * 100 : 0;
                                    }
                                    heightPercent = Math.max(0, endPerc - startPerc);
                                } else {
                                    startPerc = getScaledHeightPercent(startVal, false);
                                    endPerc = getScaledHeightPercent(endVal, false);
                                    heightPercent = Math.max(0, endPerc - startPerc);
                                }

                                const formattedVal = isPercentageChart ? `${value.toFixed(1)}%` : formatTick(value);
                                return `
                                    <span 
                                        class="omni-chart-segment js-chart-trigger cursor-pointer" 
                                        data-height="${heightPercent}" 
                                        style="height:0%; background:${legendItem.color}" 
                                        data-type="bar"
                                        data-cohort="${legendItem.key}"
                                        data-title="${legendItem.label} • ${month}"
                                        data-color="${legendItem.color}"
                                        data-percent="${formattedVal}"
                                        title="${legendItem.label}: ${formattedVal}">
                                    </span>
                                `;
                            })
                            .join("");

                        const formattedTotal = isPercentageChart 
                            ? (chartConfig.maxY ? `${monthTotal.toFixed(1)}%` : "100%") 
                            : formatTick(monthTotal);
                        return `
                            <div class="omni-chart-group" style="width: 3.5rem;">
                                <div class="omni-chart-stack" role="img" aria-label="${month}: ${formattedTotal} total">
                                    ${segments}
                                </div>
                                <span class="omni-chart-month">${month}</span>
                            </div>
                        `;
                    })
                    .join("");
            }

            const barsStyle = isPercentageChart 
                ? (selectedRange.isGrouped ? "gap: 2.25rem; justify-content: center; width: 100%; padding: 0 0.5rem;" : "gap: 2rem; justify-content: center; width: 100%; padding: 0 0.5rem;")
                : "gap: 1.25rem; padding: 0 0.5rem;";

            plotEl.innerHTML = `
                <div class="omni-chart-grid">${gridLines.join("")}</div>
                <div class="omni-chart-bars" style="${barsStyle}">${barsMarkup}</div>
            `;

            // Animate the height transition of the bars on render
            if (hasIntersected) {
                setTimeout(() => {
                    const segments = plotEl.querySelectorAll(".omni-chart-segment");
                    segments.forEach((seg) => {
                        const targetHeight = seg.getAttribute("data-height");
                        if (targetHeight) {
                            seg.style.height = `${targetHeight}%`;
                        }
                    });
                }, 30);
            }

            // Setup dynamic label at the bottom describing the X-axis category style (e.g. Persons, Genders, Timeframe)
            let xLabelEl = rangeEl.closest(".omni-chart-shell")?.querySelector(".omni-chart-xaxis-label");
            
            // Determine X-label text color dynamically based on parent panel's class
            const parentPanel = rangeEl.closest("[class*='accent-']");
            let xLabelColorClass = isPercentageChart ? "text-teal-400" : "text-purple-400";
            if (parentPanel) {
                if (parentPanel.classList.contains("accent-cyan")) {
                    xLabelColorClass = "text-teal-400";
                } else if (parentPanel.classList.contains("accent-purple")) {
                    xLabelColorClass = "text-purple-400";
                } else if (parentPanel.classList.contains("accent-red")) {
                    xLabelColorClass = "text-red-400";
                }
            }

            if (!xLabelEl) {
                xLabelEl = document.createElement("div");
                xLabelEl.className = `omni-chart-xaxis-label text-center font-bold text-[11px] uppercase tracking-wider mt-5 ${xLabelColorClass}`;
                const layoutEl = rangeEl.closest(".omni-chart-shell")?.querySelector(".omni-chart-layout");
                if (layoutEl) {
                    layoutEl.after(xLabelEl);
                }
            }

            if (isPercentageChart) {
                if (selectedRange.isGrouped) {
                    xLabelEl.textContent = selectedRange.xAxisLabel || "Pharmaceutical Accounts";
                } else {
                    xLabelEl.textContent = rangeValue === "genders" ? "Genders" : (selectedRange.xAxisLabel || "Persons");
                }
            } else {
                xLabelEl.textContent = selectedRange.xAxisLabel || "Timeframe";
            }
            xLabelEl.className = `omni-chart-xaxis-label text-center font-bold text-[11px] uppercase tracking-wider mt-5 ${xLabelColorClass}`;

            if (subtitleEl) {
                subtitleEl.textContent = `${selectedRange.label} stacked category totals ${subtitlePrefix || ""}.`;
            }

            const updateHighlight = (cohortId) => {
                activeCohort = cohortId || "all";
                const legendButtons = legendEl.querySelectorAll(".omni-chart-legend-item");
                const segments = plotEl.querySelectorAll(".omni-chart-segment");

                if (activeCohort === "all") {
                    segments.forEach((seg) => {
                        seg.style.opacity = "1";
                        seg.style.filter = "";
                    });
                    legendButtons.forEach((btn) => {
                        btn.style.opacity = "0.95";
                    });
                } else {
                    segments.forEach((seg) => {
                        const match = seg.getAttribute("data-cohort") === activeCohort;
                        seg.style.opacity = match ? "1" : "0.18";
                        seg.style.filter = match ? "brightness(1.1)" : "brightness(0.65)";
                    });
                    legendButtons.forEach((btn) => {
                        const match = btn.getAttribute("data-key") === activeCohort;
                        btn.style.opacity = match ? "1" : "0.35";
                    });
                }
            };

            legendEl.querySelectorAll(".omni-chart-legend-item").forEach((btn) => {
                btn.addEventListener("click", () => {
                    const key = btn.getAttribute("data-key");
                    const next = activeCohort === key ? "all" : key;
                    updateHighlight(next);
                });
            });

            // Initialize highlight state
            updateHighlight(activeCohort);

            // Hover and click listeners on dynamically generated segment triggers to bind with the global theme overlay tooltip/modal popup
            const triggers = plotEl.querySelectorAll(".js-chart-trigger");
            triggers.forEach((trigger) => {
                trigger.addEventListener("mouseenter", (e) => {
                    if (!isMobile) showOverlay(trigger, e);
                });
                trigger.addEventListener("mouseleave", () => {
                    if (!isMobile) hideOverlay();
                });
                trigger.addEventListener("click", (e) => {
                    if (isMobile) showOverlay(trigger, e);
                });
            });
        };

        if (chartConfig.ranges.length > 1) {
            rangeEl.innerHTML = chartConfig.ranges
                .map((item) => `<option value="${item.value}">${item.label}</option>`)
                .join("");
        } else {
            rangeEl.style.display = "none";
        }

        const defaultRange = chartConfig.defaultRange || chartConfig.ranges[0]?.value;
        if (defaultRange) {
            rangeEl.value = defaultRange;
            renderChart(defaultRange);
        }

        rangeEl.addEventListener("change", () => {
            hasIntersected = true; // User interaction forces render animation
            renderChart(rangeEl.value);
        });

        const chartObserver = new IntersectionObserver((entries, obs) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    hasIntersected = true;
                    renderChart(rangeEl.value);
                    obs.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });

        chartObserver.observe(plotEl);
    };

    if (configData.netflixBarChart) {
        setupOmniStackedChart(configData.netflixBarChart, {
            rangeEl: document.getElementById("omni-chart-range"),
            legendEl: document.getElementById("omni-chart-legend"),
            yAxisEl: document.getElementById("omni-chart-y-axis"),
            plotEl: document.getElementById("omni-chart-plot"),
        });
    }

    if (configData.netflixPurpleChart) {
        setupOmniStackedChart(configData.netflixPurpleChart, {
            rangeEl: document.getElementById("omni-purple-chart-range"),
            legendEl: document.getElementById("omni-purple-chart-legend"),
            yAxisEl: document.getElementById("omni-purple-chart-y-axis"),
            plotEl: document.getElementById("omni-purple-chart-plot"),
        });
    }

    if (configData.netflixRedChart) {
        setupOmniStackedChart(configData.netflixRedChart, {
            rangeEl: document.getElementById("omni-red-chart-range"),
            legendEl: document.getElementById("omni-red-chart-legend"),
            yAxisEl: document.getElementById("omni-red-chart-y-axis"),
            plotEl: document.getElementById("omni-red-chart-plot"),
        });
    }

    // Build Fan Insights as a horizontal bar graph instead of grid cards
    const fanInsightsContainers = document.querySelectorAll("#sports-insights-grid, #tv-viewing-share-grid");
    if (fanInsightsContainers.length && configData.fanInsights) {
        // Change the container classes dynamically from grid to flex-column
        fanInsightsContainers.forEach((container) => {
            container.className = "mt-6 flex flex-col gap-4 text-white w-full pr-1";
        });

        const maxVal = Math.max(...configData.fanInsights.map(item => parseFloat(item.front))) || 13;

        const fanInsightsMarkup = configData.fanInsights.map((card, idx) => {
            const val = parseFloat(card.front) || 0;
            const widthPercent = maxVal > 0 ? (val / maxVal) * 100 : 0;
            const isHighlight = card.title.toUpperCase().includes("FOX") && card.title.toUpperCase().includes("ROKU");
            
            // Highlight color is #F40952 (vibrant pink), other bars are #E2979A (subtle rose-pink)
            const color = isHighlight ? "#F40952" : "#E2979A";

            return `
                <div class="flex flex-col gap-1 w-full relative">
                    <div class="flex justify-between items-baseline text-sm font-semibold tracking-wide">
                        <span class="${isHighlight ? 'text-white font-extrabold' : 'text-white/60 font-medium'} text-xs sm:text-sm uppercase tracking-wider">${card.title}</span>
                        <span class="font-display text-base sm:text-lg text-white font-bold">${card.front}</span>
                    </div>
                    <div class="w-full bg-white/10 h-3 rounded-full overflow-hidden p-[1px] relative">
                        <div class="js-fan-insights-bar h-full rounded-full" 
                             style="width: 0%; background: ${color}; transition: width 1.5s cubic-bezier(0.16, 1, 0.3, 1);" 
                             data-width="${widthPercent}%">
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        fanInsightsContainers.forEach((container) => {
            container.innerHTML = fanInsightsMarkup;
        });

        // Use IntersectionObserver to animate the bars sequentially when scrolled into view
        const fanObserver = new IntersectionObserver((entries, obs) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const bars = entry.target.querySelectorAll(".js-fan-insights-bar");
                    bars.forEach((bar, idx) => {
                        setTimeout(() => {
                            bar.style.width = bar.getAttribute("data-width");
                        }, idx * 100); // 100ms stagger delay
                    });
                    obs.unobserve(entry.target);
                }
            });
        }, { threshold: 0.05 });

        fanInsightsContainers.forEach((container) => {
            fanObserver.observe(container);
        });
    }
    
    // Build Sources List
    const sourcesListEl = document.getElementById("sources-list");
    if (sourcesListEl && configData.sources) {
        sourcesListEl.innerHTML = configData.sources.map(source => `
            <div>
                <h3 class="source-title">${source.title}</h3>
                <p class="text-xs sm:text-sm text-white/80 whitespace-pre-line">${source.description}</p>
            </div>
        `).join('');
    }
    
})();

const streamingList = document.querySelector("#streaming-list");
const jumpLinks = document.querySelectorAll("[data-scroll-target]");

let currentDisplayCount = 10;
let currentCategory = "Overall";

function renderStreamingList(dataKey, displayCount) {
    const shows = tabData[dataKey] || tabData["Overall"] || tabData;

    const orangeColors = [
        "#FF9409", // bright neon orange
        "#D16F00", // bright rust orange
        "#FF645D", // bright coral-red
        "#FF8886", // soft salmon-pink
        "#FF9C56", // pastel orange
        "#FED69A", // pale warm cream
        "#BE9A00", // gold / olive-yellow
        "#B68A7D", // muted rose / warm gray
        "#A54B00", // dark orange / rust
        "#9C714B", // golden brown
        "#FFBFBB"  // light strawberry
    ];

    if (streamingList) {
        const visibleShows = shows.slice(0, displayCount);

        streamingList.innerHTML = visibleShows
            .map(
                (show, index) => {
                    const color = orangeColors[index % orangeColors.length];
                    return `
                        <article class="show-item !pl-0">
                            <div class="flex items-center gap-4 w-full">
                                <!-- Rank & Poster -->
                                <div class="relative flex-shrink-0 w-[45px] h-[58px] rounded overflow-hidden shadow-md">
                                    <span class="absolute top-[2px] left-[2px] bg-black/80 text-white/95 text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center z-10 select-none">${index + 1}</span>
                                    <img src="${show.poster}" alt="${show.title} Poster" class="w-full h-full object-cover" onerror="this.src='./assets/images/posters/bridgerton.jpg'" />
                                    ${show.missingThumbnail ? `<span class="absolute bottom-0 inset-x-0 bg-red-600/90 text-[6px] py-0.5 text-center uppercase font-bold text-white select-none">No Cover</span>` : ''}
                                </div>
                                
                                <!-- Details & Simple Bar -->
                                <div class="flex-1 min-w-0 flex flex-col gap-1">
                                    <div class="flex justify-between items-baseline text-sm gap-2">
                                        <span class="text-white font-extrabold text-[14px] uppercase tracking-wide leading-tight break-words">${show.title}</span>
                                    </div>
                                    <div class="w-full bg-white/5 h-[1.35rem] rounded overflow-hidden p-[1px] relative flex items-center">
                                        <div class="js-grow-w h-full rounded flex items-center pl-3" 
                                             style="width: 0%; background: ${color}; transition: width 1.3s cubic-bezier(0.16, 1, 0.3, 1);" 
                                             data-target="${show.width}">
                                            <span class="font-sans font-black text-[10px] text-black pr-2 select-none">${show.minutes}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </article>
                    `;
                }
            )
            .join("");

        // Maximum display sizing
        const listContainer = streamingList.parentElement;
        if (listContainer) {
            listContainer.style.maxHeight = "1091px"; 
        }
    }

    // Handle horizontal bar animations immediately if we are already scrolled to and viewing the tabs
    setTimeout(() => {
        if (streamingList) {
            const rect = streamingList.getBoundingClientRect();
            const isVisible = rect.top < window.innerHeight && rect.bottom > 0;
            if (isVisible) {
                streamingList.querySelectorAll(".js-grow-w").forEach(span => {
                    span.style.width = span.getAttribute("data-target");
                    span.classList.remove("js-grow-w");
                });
            }
        }
    }, 50);
}

// Initial render handled synchronously now
renderStreamingList(currentCategory, currentDisplayCount);

// Ensure the intersection observer runs when elements become visible
const observerOptions = {
    root: null,
    rootMargin: "0px",
    threshold: 0.1
};

const activeCountAnimations = new WeakMap();

const formatAnimatedValue = (value, decimals = 0) => {
    if (decimals > 0) {
        return Number(value).toLocaleString("en-US", {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals
        });
    }

    return Math.floor(value).toLocaleString("en-US");
};

const animateValue = (obj, start, end, duration, prefix = "", suffix = "", decimals = 0) => {
    const existingAnimation = activeCountAnimations.get(obj);
    if (existingAnimation) {
        window.cancelAnimationFrame(existingAnimation);
    }

    obj.innerHTML = prefix + formatAnimatedValue(start, decimals) + suffix;

    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        
        let current = progress * (end - start) + start;
        const displayValue = formatAnimatedValue(current, decimals);

        obj.innerHTML = prefix + displayValue + suffix;
        if (progress < 1) {
            const nextFrame = window.requestAnimationFrame(step);
            activeCountAnimations.set(obj, nextFrame);
        } else {
            activeCountAnimations.delete(obj);
        }
    };

    const firstFrame = window.requestAnimationFrame(step);
    activeCountAnimations.set(obj, firstFrame);
};

const animateCountUpElement = (el, start = 0) => {
    const target = parseFloat(el.getAttribute("data-target"));
    const prefix = el.getAttribute("data-prefix") || "";
    const suffix = el.getAttribute("data-suffix") || "";
    const decimals = parseInt(el.getAttribute("data-decimals")) || 0;

    // Speed up small-value animations so percentages like 1-5 do not feel sluggish.
    let duration = 2000;
    const absTarget = Math.abs(target);
    if (absTarget <= 5) {
        duration = 700;
    } else if (absTarget <= 15) {
        duration = 1000;
    } else if (absTarget <= 40) {
        duration = 1400;
    }

    animateValue(el, start, target, duration, prefix, suffix, decimals);
};

const statsObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const section = entry.target;

            // 1. Animate Numbers
            section.querySelectorAll(".js-count-up").forEach(el => {
                animateCountUpElement(el);
                // Remove class to prevent accidental re-runs
                el.classList.remove("js-count-up");
            });
            
            // 2. Animate Vertical Bars (height)
            section.querySelectorAll(".js-grow-h").forEach(el => {
                const targetHeight = el.getAttribute("data-target");
                setTimeout(() => {
                    el.style.height = targetHeight;
                }, 100);
                el.classList.remove("js-grow-h");
            });

            // 3. Animate Horizontal Bars (width)
            section.querySelectorAll(".js-grow-w").forEach(el => {
                const targetWidth = el.getAttribute("data-target");
                setTimeout(() => {
                    el.style.width = targetWidth;
                }, 100);
                el.classList.remove("js-grow-w");
            });
            
            // Stop observing this entire section so it only triggers once
            observer.unobserve(section);
        }
    });
}, observerOptions);

// Attach observer to the parent sections/panels instead of individual elements
document.querySelectorAll("section, .panel, article").forEach(section => {
    if (section.querySelector(".js-count-up, .js-grow-h, .js-grow-w")) {
        statsObserver.observe(section);
    }
});

// Fan Insights refresh behavior has been replaced with the flip layout handled dynamically above.

// --- Chart Overlay / Tooltip Logic ---
const overlay = document.getElementById("chart-overlay");
const overlayBox = document.getElementById("chart-overlay-box");
const overlayBackdrop = document.getElementById("chart-overlay-backdrop");
const overlayClose = document.getElementById("chart-overlay-close");

const titleEl = document.getElementById("chart-overlay-title");
const dotEl = document.getElementById("chart-overlay-dot");
const percentEl = document.getElementById("chart-overlay-percent");
const logoEl = document.getElementById("chart-overlay-logo");
const logoContainerEl = document.getElementById("chart-overlay-logo-container");

let isMobile = window.innerWidth < 640;
window.addEventListener("resize", () => {
    isMobile = window.innerWidth < 640;
    // Hide overlay on resize to reset state cleanly
    hideOverlay();
});

function showOverlay(el, event) {
    const type = el.getAttribute("data-type");
    const title = el.getAttribute("data-title");
    const color = el.getAttribute("data-color");
    const percent = el.getAttribute("data-percent");

    // Populate data
    titleEl.textContent = title;
    dotEl.style.backgroundColor = color;
    percentEl.textContent = percent;
    
    // It's a bar
    const logoSrc = el.getAttribute("data-logo");
    if (logoSrc) {
        logoEl.src = logoSrc;
        logoContainerEl.classList.remove("hidden");
    } else {
        logoContainerEl.classList.add("hidden");
    }

    if (!isMobile) {
        // Desktop: Position as a tooltip above the bar
        const rect = el.getBoundingClientRect();
        // Calculate center of the bar, then position the box above it
        const top = rect.top;
        const left = rect.left + (rect.width / 2);
        
        // Remove fixed center alignments for mobile, apply raw pixels
        overlayBox.style.marginTop = "-15px"; // Gap above the bar
        overlayBox.style.top = `${top}px`;
        overlayBox.style.left = `${left}px`;
        
        // Make it visible to hover events
        overlay.classList.remove("pointer-events-none");
        overlay.classList.add("opacity-100");
        
        // Fade in box
        overlayBox.classList.remove("opacity-0", "translate-y-4", "sm:translate-y-0");
        overlayBox.classList.add("opacity-100");
    } else {
        // Mobile: Show as fixed modal center screen
        overlayBox.style.top = "";
        overlayBox.style.left = "";
        overlayBox.style.marginTop = "";
        
        // Enable pointer events on wrapper
        overlay.classList.remove("pointer-events-none");
        overlay.classList.remove("sm:pointer-events-none");
        
        // Fade in wrapper and backdrop
        overlay.classList.add("opacity-100", "pointer-events-auto");
        
        // Slide up modal box
        overlayBox.classList.remove("opacity-0", "translate-y-4");
        overlayBox.classList.add("opacity-100", "translate-y-0");
    }
}

function hideOverlay() {
    overlay.classList.remove("opacity-100", "pointer-events-auto");
    overlay.classList.add("opacity-0", "pointer-events-none", "sm:pointer-events-none");
    
    overlayBox.classList.remove("opacity-100", "translate-y-0");
    overlayBox.classList.add("opacity-0", "translate-y-4", "sm:translate-y-0");
}

document.querySelectorAll(".js-chart-trigger").forEach(trigger => {
    // Desktop hover
    trigger.addEventListener("mouseenter", (e) => {
        if (!isMobile) showOverlay(trigger, e);
    });
    trigger.addEventListener("mouseleave", () => {
        if (!isMobile) hideOverlay();
    });
    
    // Mobile click
    trigger.addEventListener("click", (e) => {
        if (isMobile) showOverlay(trigger, e);
    });
});

// Mobile close behaviors
overlayBackdrop.addEventListener("click", hideOverlay);
overlayClose.addEventListener("click", hideOverlay);

// --- Drag-to-Scroll & Horizontal Mousewheel support for Top Streaming Shows Tabs ---
const setupTabContainerScroll = () => {
    const container = document.querySelector("#streaming-shows .overflow-x-auto");
    if (!container) return;

    let isDown = false;
    let startX;
    let scrollLeft;

    container.addEventListener("mousedown", (e) => {
        isDown = true;
        startX = e.pageX - container.offsetLeft;
        scrollLeft = container.scrollLeft;
        container.style.cursor = "grabbing";
    });

    container.addEventListener("mouseleave", () => {
        isDown = false;
        container.style.cursor = "grab";
    });

    container.addEventListener("mouseup", () => {
        isDown = false;
        container.style.cursor = "grab";
    });

    container.addEventListener("mousemove", (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - container.offsetLeft;
        const walk = (x - startX) * 2; // scroll-fast multiplier
        container.scrollLeft = scrollLeft - walk;
    });

    // Horizontal wheel scroll redirect
    container.addEventListener("wheel", (e) => {
        if (e.deltaY !== 0) {
            e.preventDefault();
            container.scrollLeft += e.deltaY;
        }
    }, { passive: false });

    // Set cursor styling initially
    container.style.cursor = "grab";
};
setupTabContainerScroll();

// --- Share Button Functionality ---
const shareButton = document.getElementById('share-button');
const shareOverlay = document.getElementById('share-overlay');
const closeOverlayBtn = document.getElementById('close-overlay');
const copyLinkBtn = document.getElementById('copy-link-btn');
const emailLinkBtn = document.getElementById('email-link-btn');
const copyNotification = document.getElementById('copy-notification');

if (shareButton && shareOverlay) {
    // Dynamically set native mailto link for robust execution
    if (emailLinkBtn) {
        const url = window.location.href;
        const subject = encodeURIComponent(document.title);
        const body = encodeURIComponent(`Check out this page: ${url}`);
        emailLinkBtn.setAttribute('href', `mailto:?subject=${subject}&body=${body}`);
    }

    shareButton.addEventListener('click', () => {
        shareOverlay.classList.remove('hidden');
        shareOverlay.classList.add('flex');
    });

    closeOverlayBtn.addEventListener('click', () => {
        shareOverlay.classList.add('hidden');
        shareOverlay.classList.remove('flex');
    });

    shareOverlay.addEventListener('click', (e) => {
        if (e.target === shareOverlay) {
            shareOverlay.classList.add('hidden');
            shareOverlay.classList.remove('flex');
        }
    });

    copyLinkBtn.addEventListener('click', () => {
        const url = window.location.href;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(url)
                .then(() => showCopySuccess())
                .catch(() => fallbackCopy(url));
        } else {
            fallbackCopy(url);
        }
    });

    function fallbackCopy(text) {
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.top = "0";
        textArea.style.left = "0";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try {
            document.execCommand('copy');
            showCopySuccess();
        } catch (err) {
            console.error('Fallback copy failed:', err);
        }
        document.body.removeChild(textArea);
    }

    function showCopySuccess() {
        if (copyNotification) {
            copyNotification.classList.remove('hidden');
            setTimeout(() => {
                copyNotification.classList.add('hidden');
            }, 3000);
        }
    }
}
