const configData = {
    "brand": {
        "name": "Netflix",
        "logo": "./assets/images/logos/netflix.svg"
    },
    "streamingShows": {
        "Overall": [
            { "title": "KPOP DEMON HUNTERS", "service": "Netflix", "episodes": "Movie", "minutes": "1.5", "width": "94%", "poster": "./assets/images/posters/KPOP DEMON HUNTERS .jpg" },
            { "title": "THE RIP", "service": "Netflix", "episodes": "Movie", "minutes": "1.3", "width": "81%", "poster": "./assets/images/posters/THE RIP.jpg" },
            { "title": "HIS & HERS", "service": "Netflix", "episodes": "Limit Series", "minutes": "1.3", "width": "81%", "poster": "./assets/images/posters/HIS & HERS.jpg" },
            { "title": "WAR MACHINE", "service": "Netflix", "episodes": "Movie", "minutes": "1.3", "width": "81%", "poster": "./assets/images/posters/WAR MACHINE.jpg" },
            { "title": "JOE'S COLLEGE ROAD TRIP", "service": "Disney+", "episodes": "Movie", "minutes": "1.2", "width": "75%", "poster": "./assets/images/posters/JOE'S COLLEGE ROAD TRIP.jpg" },
            { "title": "PEOPLE WE MEET ON VACATION", "service": "Netflix", "episodes": "Movie", "minutes": "1.3", "width": "81%", "poster": "./assets/images/posters/PEOPLE WE MEET ON VACATION.jpg" },
            { "title": "EVIL INFLUENCER: THE JODI HILDEBRANDT STORY", "service": "Netflix", "episodes": "Documentary", "minutes": "1.2", "width": "75%", "poster": "./assets/images/posters/EVIL INFLUENCER THE JODI HILDEBRANDT STORY.jpg" },
            { "title": "REALITY CHECK: INSIDE AMERICA'S NEXT TOP MODEL", "service": "Netflix", "episodes": "Docuseries", "minutes": "1.1", "width": "69%", "poster": "./assets/images/posters/REALITY CHECK INSIDE AMERICA'S NEXT TOP MODEL.jpg" },
            { "title": "KIDNAPPED: ELIZABETH SMART", "service": "Netflix", "episodes": "Movie", "minutes": "1.2", "width": "75%", "poster": "./assets/images/posters/KIDNAPPED ELIZABETH SMART.jpg" },
            { "title": "WAKE UP DEAD MAN: A KNIVES OUT MYSTERY", "service": "Netflix", "episodes": "Movie", "minutes": "1.6", "width": "100%", "poster": "./assets/images/posters/WAKE UP DEAD MAN A KNIVES OUT MYSTERY.jpg" }
        ]
    },
    "fanInsights": [
        {
            "title": "YouTube",
            "front": "12.8%",
            "back": "12.8%"
        },
        {
            "title": "Disney",
            "front": "10.8%",
            "back": "10.8%"
        },
        {
            "title": "FOX + ROKU",
            "front": "10.1%",
            "back": "10.1%"
        },
        {
            "title": "NBCU/Versant",
            "front": "9.9%",
            "back": "9.9%"
        },
        {
            "title": "Netflix",
            "front": "8.5%",
            "back": "8.5%"
        },
        {
            "title": "Paramount",
            "front": "7.8%",
            "back": "7.8%"
        },
        {
            "title": "Warner Bros Discovery",
            "front": "5.6%",
            "back": "5.6%"
        },
        {
            "title": "Amazon",
            "front": "3.9%",
            "back": "3.9%"
        },
        {
            "title": "Scripps",
            "front": "1.7%",
            "back": "1.7%"
        },
        {
            "title": "Weigel",
            "front": "1.3%",
            "back": "1.3%"
        },
        {
            "title": "A&E",
            "front": "0.9%",
            "back": "0.9%"
        }
    ],
    "tvViewsInsights": [
        {"value": 9, "copy": "of all Apple TV viewing"},
        {"value": 4, "copy": "of all Netflix viewing"},
        {"value": 3, "copy": "of all Hulu viewing"},
        {"value": 3, "copy": "of all Peacock viewing"},
        {"value": 2, "copy": "of all HBO Max viewing"},
        {"value": 2, "copy": "of total streaming accross the board"},
    ],
    "netflixBarChart": {
        "isPercentage": true,
        "maxY": 80,
        "defaultRange": "investment_by_industry",
        "legend": [
            { "key": "pharma", "label": "Pharma", "color": "#4c1d95" },
            { "key": "auto", "label": "Auto", "color": "#5b21b6" },
            { "key": "insurance", "label": "Insurance", "color": "#6d28d9" },
            { "key": "retail", "label": "Retail", "color": "#7c3aed" },
            { "key": "restaurants", "label": "Restaurants", "color": "#8b5cf6" },
            { "key": "telecom", "label": "Telecom", "color": "#a78bfa" },
            { "key": "engineering", "label": "Engineering & Prof. Services", "color": "#c4b5fd" },
            { "key": "tv_programs", "label": "TV Programs", "color": "#ddd6fe" },
            { "key": "financial", "label": "Financial", "color": "#312e81" },
            { "key": "physical_culture", "label": "Physical Culture", "color": "#3730a3" },
            { "key": "tv_networks", "label": "TV Networks", "color": "#4338ca" },
            { "key": "soaps", "label": "Soaps & Detergents", "color": "#4f46e5" },
            { "key": "prepared_foods", "label": "Prepared & Convenience Foods", "color": "#6366f1" },
            { "key": "software", "label": "Computer Software", "color": "#818cf8" }
        ],
        "ranges": [
            {
                "value": "investment_by_industry",
                "label": "By Industry Category",
                "xAxisLabel": "Streaming Platforms",
                "months": ["Disney+", "Prime Video", "HBO Max", "Hulu", "Netflix", "Paramount+", "Peacock", "YouTube"],
                "series": {
                    "pharma": [13.4, 17.0, 16.3, 16.8, 14.1, 14.7, 16.4, 13.5],
                    "auto": [11.3, 8.6, 7.9, 7.5, 8.5, 6.9, 12.4, 8.1],
                    "insurance": [9.0, 10.4, 9.5, 7.5, 6.1, 6.1, 11.7, 7.0],
                    "retail": [6.3, 4.7, 6.7, 9.4, 7.5, 6.6, 7.1, 7.7],
                    "restaurants": [5.3, 4.6, 4.5, 4.3, 7.0, 4.8, 6.6, 5.2],
                    "telecom": [5.2, 6.3, 3.7, 5.3, 7.5, 5.3, 6.6, 4.5],
                    "engineering": [4.4, 4.8, 0.0, 6.3, 5.3, 5.1, 3.3, 8.3],
                    "tv_programs": [4.3, 0.0, 3.9, 3.4, 4.2, 0.0, 5.0, 4.6],
                    "financial": [3.8, 3.1, 0.0, 0.0, 3.5, 2.4, 2.9, 0.0],
                    "physical_culture": [3.6, 0.0, 3.7, 3.5, 0.0, 2.5, 0.0, 3.1],
                    "tv_networks": [0.0, 3.1, 10.6, 0.0, 0.0, 3.7, 0.0, 4.4],
                    "soaps": [0.0, 3.5, 3.7, 0.0, 0.0, 0.0, 0.0, 0.0],
                    "prepared_foods": [0.0, 0.0, 0.0, 3.2, 0.0, 0.0, 0.0, 0.0],
                    "software": [0.0, 0.0, 0.0, 0.0, 3.0, 0.0, 2.3, 0.0]
                }
            }
        ]
    },
    "netflixPurpleChart": {
        "isPercentage": true,
        "defaultRange": "demographics",
        "legend": [
            { "key": "p2_17", "label": "P2-17", "color": "#0d9488" },
            { "key": "p18_34", "label": "P18-34", "color": "#14b8a6" },
            { "key": "p35_49", "label": "P35-49", "color": "#2dd4bf" },
            { "key": "p50_64", "label": "P50-64", "color": "#5eead4" },
            { "key": "p65_plus", "label": "P65+", "color": "#99f6e4" }
        ],
        "ranges": [
            {
                "value": "demographics",
                "label": "By Age Demographics",
                "xAxisLabel": "Streaming Platforms",
                "months": ["Prime Video", "Apple TV", "Disney Streaming*", "HBO Max", "Netflix", "Paramount+", "Peacock", "YouTube"],
                "series": {
                    "p2_17": [12.2, 7.4, 20.6, 8.6, 18.6, 16.1, 9.9, 24.0],
                    "p18_34": [17.6, 18.2, 28.9, 31.4, 21.3, 18.7, 23.8, 20.9],
                    "p35_49": [23.6, 30.8, 25.2, 28.5, 24.4, 22.8, 28.4, 18.6],
                    "p50_64": [26.2, 27.3, 16.2, 23.0, 21.1, 25.7, 23.7, 19.4],
                    "p65_plus": [20.4, 16.2, 9.1, 8.6, 14.6, 16.7, 14.1, 17.0]
                }
            }
        ]
    },
    "netflixRedChart": {
        "isPercentage": true,
        "defaultRange": "distributor_usage",
        "legend": [
            { "key": "broadcast", "label": "Broadcast", "color": "#ef4444" },
            { "key": "cable", "label": "Cable", "color": "#f87171" },
            { "key": "streaming", "label": "Streaming", "color": "#fca5a5" }
        ],
        "ranges": [
            {
                "value": "distributor_usage",
                "label": "By Distribution Split",
                "xAxisLabel": "2025",
                "months": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                "series": {
                    "broadcast": [61.2, 60.1, 43.6, 43.8, 30.5, 47.7, 42.2, 43.1, 68.3, 60.8, 75.8, 62.4],
                    "cable": [36.6, 39.9, 56.4, 56.2, 68.5, 50.4, 57.8, 56.5, 26.6, 33.2, 18.5, 22.2],
                    "streaming": [2.2, 0.0, 0.0, 0.0, 1.0, 1.9, 0.0, 0.4, 5.2, 6.0, 5.7, 15.4]
                }
            }
        ]
    },
    "sources": [
        { "title": "Source 1", "description": "Nielsen Ad Intel" },
        { "title": "Source 2", "description": "Nielsen Streaming Platform Ratings. *Disney Streaming includes Disney+, Hulu, and ESPN." },
        { "title": "Source 3", "description": "Nielsen NPOWER, National Panel and Streaming Platform Ratings for Streaming Data. Share of total persons 2+ usage based on minutes viewed to all media distributor national entities.\n\nViewing to local stations or syndicators is reflected in the appropriate broadcast affiliate or cable network. NOTES: Unrounded totals can exceed the sum of rounded shares. The Gauge and Media Distributor Gauge (MDG) do not reflect Nielsen's currency TV ratings. Nielsen is working on updates to The Gauge and MDG to better reflect currency for the Fall TV season, at which time we will provide back data to assist in the transition." },
        { "title": "Source 4", "description": "Nielsen National TV Panel Data augmented by Streaming Platform Ratings, based on minutes viewed by persons 2+, “Sports” = Sports Events, excluding those less than 10 minutes in duration, and excluding repeats" },
        { "title": "Source 5", "description": "Nielsen Content Ratings. Top 10 based on P2+ impressions. Average viewers per household = persons 2+ impressions/household impressions" },
    ]
};